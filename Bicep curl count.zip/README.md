# TF-Bicep-curl-count

Note:- Please move to a area where your whole body is visible so that we can predict perfectly

# Library used
https://github.com/tensorflow/tfjs-models/tree/master/pose-detection/src/movenet libray is used to detect pose.


# Access The Live Website here

https://santoshnayak.github.io/TF-Bicep-curl-count
